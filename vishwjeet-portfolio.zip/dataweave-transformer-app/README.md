# DataWeave Transformer Web App 🧩

A colorful React web app that auto-generates DataWeave (DWL) code based on input/output formats.

## 🔧 Features
- Select Input/Output MIME type
- Paste your input payload
- Get a simulated DWL transform instantly

## 🛠️ Tech Stack
- React + TailwindCSS
- shadcn/ui (optional)
- Supports basic DataWeave generation logic

## 🚀 How to Run
```bash
npm install
npm run dev
```

## 🌐 Demo (coming soon)
Deploy to GitHub Pages or Vercel!

---

👨‍💻 Built by Vishwjeet Kumar | [LinkedIn](https://www.linkedin.com/in/vishwjeet-kumar-52232b24b/)
